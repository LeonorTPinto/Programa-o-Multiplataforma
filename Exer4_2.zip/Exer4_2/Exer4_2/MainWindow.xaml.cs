﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exer4_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            BloquearEdicaoTextBox();
            lerficheiro();

        }

        private void tbmodificar_Click(object sender, RoutedEventArgs e)
        {
            ModificarDados janela= new ModificarDados();
            if (janela.ShowDialog() == true)
            {
                tbnumero = janela.tbnumero;
                tbnome=janela.tbnome;
                tbcurso = janela.tbcurso;
            }
        }


        private void BloquearEdicaoTextBox()
        {
            // Define a TextBox como somente leitura
            tbnumero.IsReadOnly = true;
            tbnome.IsReadOnly = true;
            tbcurso.IsReadOnly = true;
        }

        private void tbSair_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void lerficheiro()
        {
            string texto="";
            StreamReader file = new StreamReader("Dados.txt");
            texto = file.ReadToEnd(); 
            file.Close();
            string[] parms = texto.Split('\n');
            tbnumero.Text = parms[0];
            tbnome.Text = parms[1];
            tbcurso.Text = parms[2];

            
        }
    }
}