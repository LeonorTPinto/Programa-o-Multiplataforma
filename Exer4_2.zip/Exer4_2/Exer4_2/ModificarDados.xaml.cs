﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Exer4_2
{
    /// <summary>
    /// Lógica interna para ModificarDados.xaml
    /// </summary>
    public partial class ModificarDados : Window
    {
        public ModificarDados()
        {
            InitializeComponent();
        }

        private void btConfirmar_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter file = new StreamWriter("Dados.txt");
            file.WriteLine(tbnumero.Text);
            file.WriteLine(tbnome.Text);
            file.WriteLine(tbcurso.Text);
            file.Close();

            this.DialogResult = true;

        }

        private void btSair_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
