﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer4_2
{
    internal class Dados
    {
        public double numero { get; set; }
        public string nome { get; set; }
        public string curso { get; set; }
    }
}
