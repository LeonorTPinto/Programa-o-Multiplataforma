﻿using exer4_2;
using System.Configuration;
using System.Data;
using System.Windows;

namespace Exer4_2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        Dados Dados_ { set; get; }

       public App()
        {
            Dados_ = new Dados();
        }
    }

}
