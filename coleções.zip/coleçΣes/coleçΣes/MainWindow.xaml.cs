﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace colecoes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private List<Figuras>_lista= new List<Figuras>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

            WindowAdicionar janela= new WindowAdicionar();

            //janela.Show(); //não bloquia a pagina a trás
            if(janela.ShowDialog()== true)// abre a janela e bloquia a janela de trás 

            {
                //
                _lista.Add(janela.FiguraNova);
                //lbFiguras.Items.Add(janela.FiguraNova.Nome);
                lbFiguras.Items.Add(janela.FiguraNova);

            }            
                    
        }

        private void lbFiguras_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(lbFiguras.SelectedItem != null)
            {
                //Figuras selecionada = _lista[lbFiguras.SelectedIndex];
                Figuras selecionada = lbFiguras.SelectedItem as Figuras;


                sbiDimensoes.Content = "Largura= " + selecionada.Largura + " Altura= " + selecionada.Altura;    
            }
            else


                sbiDimensoes.Content = "Largura= ? Altura= ?";

        }
        }
    }
}