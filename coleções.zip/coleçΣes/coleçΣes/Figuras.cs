﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace colecoes
{
    public class Figuras
    {
        public string Nome { get; set; }
        public string Altura { get; set; }
        public string Largura{ get; set;}

        public override string ToString()
            {
            return Nome + "[" + Largura + ":" + Altura + "]";
            }

    }

    
}
